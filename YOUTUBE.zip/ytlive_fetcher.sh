#!/data/data/com.termux/files/usr/bin/bash

# === Config ===
WORKDIR="/storage/emulated/0/r1d3x6/YOUTUBE"
CHANNELS_FILE="$WORKDIR/channels.txt"
OUTPUT_PLAYLIST="$WORKDIR/ytlive_r1d3x6.m3u"
LOG_FILE="$WORKDIR/fetch_log.json"
LOGO_MAP="$WORKDIR/logomap.json"

# === GitHub ===
GITHUB_REPO="https://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@github.com/ggkaku/orytkkz.git"
GIT_EMAIL="rolod66342@kissgy.com"
GIT_USER="ggkaku"

# === Telegram ===
BOT_TOKEN="8195506980:AAERvU5WovQu-PnMjfWR-WUC42SFqTTa7uE"
CHAT_ID="7369367685"

# === Init ===
cd "$WORKDIR" || exit 1
> "$OUTPUT_PLAYLIST"
echo "[]" > "$LOG_FILE"

send_telegram() {
  curl -s -X POST "https://api.telegram.org/bot$BOT_TOKEN/sendMessage" \
  -d chat_id="$CHAT_ID" -d text="$1" > /dev/null
}

get_logo() {
  CHANNEL_KEY="$1"
  jq -r --arg key "$CHANNEL_KEY" '.[$key] // empty' "$LOGO_MAP" 2>/dev/null
}

# === Processing ===
while read -r URL; do
  [ -z "$URL" ] && continue

  CHANNEL_ID=$(yt-dlp --get-id "$URL" 2>/dev/null | head -n1)
  CHANNEL_NAME=$(yt-dlp --get-description "$URL" 2>/dev/null | head -n1)

  echo "📺 Checking: $CHANNEL_NAME"

  INFO_JSON=$(yt-dlp -j --flat-playlist "$URL" 2>/dev/null | jq 'select(.is_live == true)' | head -n1)

  if [ -z "$INFO_JSON" ]; then
    jq ". += [{\"channel\": \"$CHANNEL_NAME\", \"status\": \"no_live\"}]" "$LOG_FILE" > "$LOG_FILE.tmp" && mv "$LOG_FILE.tmp" "$LOG_FILE"
    send_telegram "⚠️ No Live Stream: $CHANNEL_NAME"
    continue
  fi

  VIDEO_ID=$(echo "$INFO_JSON" | jq -r '.id')
  TITLE=$(echo "$INFO_JSON" | jq -r '.title')
  THUMBNAIL=$(echo "$INFO_JSON" | jq -r '.thumbnail // empty')
  CHANNEL_KEY=$(basename "$URL")
  LOGO_URL=$(get_logo "$CHANNEL_KEY")

  [ -z "$LOGO_URL" ] && LOGO_URL="$THUMBNAIL"
  [ -z "$LOGO_URL" ] && LOGO_URL="https://i.imgur.com/404.png" # fallback

  STREAM_URL="https://www.youtube.com/watch?v=$VIDEO_ID"
  echo -e "#EXTINF:-1 tvg-id=\"$CHANNEL_ID\" tvg-name=\"$CHANNEL_NAME\" tvg-logo=\"$LOGO_URL\" group-title=\"YouTube Live\",$CHANNEL_NAME\n$STREAM_URL" >> "$OUTPUT_PLAYLIST"

  jq ". += [{\"channel\": \"$CHANNEL_NAME\", \"status\": \"success\", \"video_id\": \"$VIDEO_ID\"}]" "$LOG_FILE" > "$LOG_FILE.tmp" && mv "$LOG_FILE.tmp" "$LOG_FILE"
  send_telegram "✅ LIVE: $CHANNEL_NAME\n🔗 $STREAM_URL"

done < "$CHANNELS_FILE"

# === Git Push ===
git config --global user.email "$GIT_EMAIL"
git config --global user.name "$GIT_USER"

[ ! -d "$WORKDIR/.git" ] && git init && git remote add origin "$GITHUB_REPO"

git add ytlive_r1d3x6.m3u fetch_log.json
git commit -m "Playlist updated on $(date '+%F %T')" || true
git branch -M main
git push -f origin main

send_telegram "🎉 Playlist update pushed to GitHub successfully!"

exit 0