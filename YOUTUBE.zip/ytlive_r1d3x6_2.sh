#!/data/data/com.termux/files/usr/bin/bash

# === Paths ===
SCRIPT_DIR="/data/data/com.termux/files/home/"
CONFIG_FILE="/storage/emulated/0/r1d3x6/YOUTUBE/telegram_config_for_ytlive_r1d3x6_2.json"
LOGO_DIR="/storage/emulated/0/r1d3x6/YOUTUBE/logos"
OUTPUT="/storage/emulated/0/r1d3x6/YOUTUBE/ytlive_r1d3x6_2.m3u"
LOG_FILE="/storage/emulated/0/r1d3x6/YOUTUBE/stream_log_of_ytlive_r1d3x6_2.txt"
GITHUB_REPO_DIR="${SCRIPT_DIR}orytkkz"  # <-- update if your folder is named differently

# === Load Telegram Settings ===
TELEGRAM_BOT_TOKEN=$(jq -r '.telegram_token' "$CONFIG_FILE")
TELEGRAM_CHAT_ID=$(jq -r '.telegram_chat_id' "$CONFIG_FILE")

# === Custom logo URLs ===
declare -A CUSTOM_LOGOS=(
  ["sportsEyeTV"]=""
  ["cricketsatv"]=""
  ["Tsportsbd"]=""
  ["atnnewsltd"]=""
  ["ACBofficial"]=""
  ["RabbitholebdSports"]=""
  ["ABCNews"]=""
  ["SportsCentralOfficial"]=""
  ["nzctv"]=""
  ["officialenglandcricket"]=""
  ["yorkscricket"]=""
  ["EssexCricketTV"]=""
  ["bcbtigercricket"]=""
  ["WindiesCricket"]=""
  ["skysportscricket"]=""
  ["ekhontv"]="https://raw.githubusercontent.com/r1d3x6/skgitvglogojkkk/refs/heads/main/ekhon-tv.png"
  ["JamunaTVbd"]="https://raw.githubusercontent.com/r1d3x6/tandjtales/refs/heads/Tom-and-Jerry-Tales/jamunatv.png"
  ["somoynews360"]="https://raw.githubusercontent.com/r1d3x6/tandjtales/refs/heads/Tom-and-Jerry-Tales/somoytv.png"
  ["channel24digital"]=""
  ["IndependentTelevision"]="https://raw.githubusercontent.com/r1d3x6/skgitvglogojkkk/refs/heads/main/indipendent.png"
  ["SaudiQuranTv"]="https://raw.githubusercontent.com/r1d3x6/skgitvglogojkkk/refs/heads/main/alquran-alkarim.png"
  ["SaudiSunnahTv"]="https://raw.githubusercontent.com/r1d3x6/skgitvglogojkkk/refs/heads/main/assunnah-annabawih.png"
)

# === Logging ===
log() {
  echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# === Telegram Notification ===
send_telegram() {
  local message="$1"
  curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
    -d chat_id="$TELEGRAM_CHAT_ID" \
    -d text="$message" >/dev/null
}

# === Termux Popup Notification ===
notify_termux() {
  if command -v termux-toast >/dev/null; then
    termux-toast -g top -b black -c green "$1"
  fi
}

# === GitHub Push Function ===
push_to_github() {
  cp "$OUTPUT" "$GITHUB_REPO_DIR/ytlive_r1d3x6_2.m3u"

  cd "$GITHUB_REPO_DIR"
  git add ytlive_r1d3x6_2.m3u
  git commit -m "Update playlist on $(date '+%Y-%m-%d %H:%M:%S')" >/dev/null 2>&1
  git push origin main >/dev/null 2>&1

  log "✅ Pushed updated .m3u to GitHub"
}

# === Fetch Stream Function ===
fetch_stream_url() {
  local channel="$1"
  local url="https://www.youtube.com/@$channel"

  log "Checking live stream for @$channel"
  stream_url=$(timeout 20 yt-dlp -g --live-from-start --no-warnings "$url" 2>/dev/null)

  if [[ -n "$stream_url" && "$stream_url" == *".m3u8"* ]]; then
    msg="✅ @$channel is LIVE"
    log "$msg"
    send_telegram "$msg"
    notify_termux "$msg"

    metadata=$(timeout 20 yt-dlp -j "$url" 2>/dev/null)
    thumbnail=$(echo "$metadata" | jq -r '.thumbnail')
    title=$(echo "$metadata" | jq -r '.title // empty')

    if [ -n "${CUSTOM_LOGOS[$channel]}" ]; then
      logo_url="${CUSTOM_LOGOS[$channel]}"
    elif [ -f "$LOGO_DIR/$channel.png" ]; then
      logo_url="file://$LOGO_DIR/$channel.png"
    else
      logo_url="$thumbnail"
    fi

    echo "#EXTINF:-1 tvg-logo=\"$logo_url\", ${title:-$channel}" >> "$OUTPUT"
    echo "$stream_url" >> "$OUTPUT"
  else
    msg="⚠️ @$channel skipped (offline or failed)"
    log "$msg"
    send_telegram "$msg"
    notify_termux "$msg"
  fi
}

# === Main Loop ===
while true; do
  log "🔄 Starting playlist refresh..."
  echo "#EXTM3U" > "$OUTPUT"

  for channel in "${!CUSTOM_LOGOS[@]}"; do
    fetch_stream_url "$channel"
  done

  msg="✅ Playlist update completed at $(date)"
  log "$msg"
  send_telegram "$msg"
  notify_termux "$msg"

  push_to_github

  log "⏱️ Sleeping for 30 minutes..."
  sleep 1800
done